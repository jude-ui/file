(function ($) {
  "use strict";
  $(document).ready(function() {
    // var scroll = new IScroll('.tab_list',{
    //   scrollX: true,
    //   scrollY: false
    // });
    // var scrollTbl = new IScroll('.wrap_tbl',{
    //   scrollX: true,
    //   scrollY: false
    // });

    // 2021-03-19 추가 시작
    var Rolling = {
      yVal: 0, // translateY 값
      num: 46, // 롤링 높이
      rollingAnimationDelay: 3.5, // 롤링 인터벌 간격(초)
      currentItemClassName: 'active',
      beforeItemClassName: 'before',
      idx: 0,
      duration: null,
      listLength: null,
      transitionDuration: null,
      rollingInterval: null,
      innerRolling: $('.inner_rolling'), // $(래퍼 구조 클래스)
      listRolling: $('.list_rolling'), // $(롤링 리스트 구조 클래스)
      listItem: null,
      initEvent: function () {
        this.duration = this.innerRolling.css('transition-duration');
        this.transitionDuration = parseFloat(this.duration) * 1000;
        this.listLength = this.innerRolling.find('li').length;
        for (var i = 0; i < this.listLength; i++) {
          this.innerRolling.find('li').eq(i).clone().appendTo(this.listRolling);
        }
        this.innerRolling.css('height',(this.num * this.listLength) - 1);
        this.innerRolling.find('li').eq(0).addClass(this.currentItemClassName);
        this.rollingStart();
      },
      
      rollingStart: function () {
        var self = this;
        this.rollingInterval = setInterval(function () {
          self.yVal += self.num;
          self.idx += 1;
          self.innerRolling.css('transition', 'transform ' + self.duration);
          self.innerRolling.css('transform', 'translateY(-' + self.yVal + 'px)');

          self.innerRolling.find('li').removeClass(self.currentItemClassName);
          self.innerRolling.find('li').removeClass(self.beforeItemClassName);
          self.innerRolling.find('li').eq(self.idx - 1).addClass(self.beforeItemClassName);
          self.innerRolling.find('li').eq(self.idx - 1).next().addClass(self.currentItemClassName);

          if( self.idx === self.listLength ){
            self.idx = 0;
            self.yVal = 0;
            var aniDelay = setTimeout(function () {
              self.innerRolling.find('li').removeClass(self.currentItemClassName);
              self.innerRolling.find('li').removeClass(self.beforeItemClassName);
              self.innerRolling.find('li').eq(0).addClass(self.currentItemClassName);
              self.innerRolling.css('transition', 'none');
              self.innerRolling.css('transform', 'translateY(0px)');
              clearTimeout(aniDelay);
            }, self.transitionDuration);
          }
        }, this.rollingAnimationDelay * 1000);
      }
    }
    Rolling.initEvent();
    // 2021-03-19 추가 끝

    // 2021-03-19 수정 시작
    // 기타 정보 알림 폴딩 박스
    $('.opt_rolling .btn_fold').on('click', function() {
      var $self = $(this);
      if ( $('.opt_rolling').hasClass('on') ) {
        $self.parents('.opt_rolling').removeClass('on');
        Rolling.rollingStart();
      } else {
        $self.parents('.opt_rolling').addClass('on');
        clearInterval(Rolling.rollingInterval);
      }
    });
    // 2021-03-19 수정 끝

    // 여론조사 언론자 폴딩
    var $foldingHead = $('.folding_head');
    var icoArr = '<span class="ico_comm"></span>';
    $foldingHead.find('.btn_fold').on('click', function() {
      var $self = $(this);
      if ($foldingHead.hasClass('extend_on')) {
        $self.parents('.folding_head').removeClass('extend_on');
        $self.attr('aria-expanded', 'false');
        $self.html('전체보기' + icoArr );
      } else {
        $self.parents('.folding_head').addClass('extend_on');
        $self.attr('aria-expanded', 'true');
        $self.html('접어두기' + icoArr );
      }
    });

    function selectTab(tabList) {
      $(tabList).find('.link_tab').on('click', function(e) {
        e.preventDefault();
        var $self = $(this);
        $self.parents(tabList).find('.link_tab').attr('aria-selected','false');
        $self.attr('aria-selected','true');
      });
    }
    selectTab('.list_tab'); // 공통 뉴스 탭
    selectTab('.list_menutab'); // GNB 탭 메뉴
    selectTab('.list_menuetc'); // ETC 페이지 탭 메뉴

    // 후보자 접기/펼치기
    var $listVs = $('.list_vs');
    
    $listVs.on('click', '.btn_more', function() {
      var $self = $(this);

      if ($self.parents('li').hasClass('fold_on')) {
        // 열린 상태일 때
        $self.parents('li').removeClass('fold_on');
        $self.html('후보자 더보기' + icoArr );
      } else {
        // 닫힌 상태일 때
        $listVs.find('li').removeClass('fold_on')
        $listVs.find('.btn_more').html('후보자 더보기' + icoArr );
        $self.parents('li').addClass('fold_on');
        $self.html('접기' + icoArr );
      }
    });
    $(document).on('click', function(e) {
      var $target = $(e.target);
      if( !($target.is('.list_vs .btn_more') || $target.parents().hasClass('fold_on')) ){
        $listVs.find('li').removeClass('fold_on');
        $listVs.find('.btn_more').html('후보자 더보기' + icoArr );
      }
    });

    // 투표율 콤보박스
    // var $optComm = $('.opt_comm');
    // $(document).on('click', function(e) {
    //   var $target = $(e.target);

    //   if ( !($target.parents().hasClass('opt_comm')) ) {
    //     $optComm.removeClass('opt_open');
    //   }
    // });
    // $optComm.find('.link_selected').on('click', function(e) {
    //   e.preventDefault();
    //   var $self = $(this);
    //   var $optComm = $self.parents('.opt_comm');

    //   if (!$optComm.hasClass('opt_open')) {
    //     $optComm.addClass('opt_open');
    //   }
    // });
    // $optComm.find('.link_opt').on('click', function(e) {
    //   e.preventDefault();
    //   var $self = $(this);
    //   var val = $self.data('value');

    //   $self.parents('.opt_comm').find('.link_selected').html(val + '<span class="ico_comm"></span>');
    //   $self.parents('.opt_comm').find('li').removeClass('on');
    //   $self.parents('li').addClass('on');
    //   $self.parents('.opt_comm').removeClass('opt_open');
    // });
  });

  // 스크롤시
  $(window).scroll(function (){
    var _h = $(document).scrollTop();

    // Top 버튼
    $(".btn_top").addClass("show");
      if (_h <= 1) {
        $(".btn_top").removeClass("show");
    };

  });
}(jQuery));