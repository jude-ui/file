<%@page import="org.apache.commons.lang.StringUtils"%>
<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.io.*, java.util.*,org.apache.commons.lang.*, org.apache.commons.io.*, org.apache.commons.io.filefilter.*"%>
<%!
    private String getPath(String ctxt, int idx, File file) {
        String fileName = FilenameUtils.separatorsToUnix(file.getAbsolutePath().substring(idx)).replaceAll(".vm", "").replaceAll("/working", "");
        return  ctxt + fileName;
    }
 
    private boolean isInclusions(String path){
        return true;
    }
 
    private boolean isExclusions(String path){
        //path.indexOf("_js") > -1 ||
        return path.indexOf("_core") > -1
            || path.indexOf("_source") > -1
            || path.indexOf(".svn") > -1
            || path.indexOf("index.html") > -1;
    }
 
    private boolean matchExtensions(String name){
        String[] extensions = new String[]{"html", "css", "js", "css.vm"};
        for(String ext : extensions){
            if(StringUtils.endsWith(name, ext)){
                return true;
            }
        }
        return false;
    }
 
%>
<%
 
    String ctxtName = request.getContextPath();
    File root = new File(application.getRealPath("/"));
    int idx = root.getAbsolutePath().length();
 
    Collection<File> files = FileUtils.listFiles(root, new IOFileFilter() {
        public boolean accept(File dir, String name) {
            return true;
        }
        public boolean accept(File file) {
            boolean ok = true;
            ok = ok && isInclusions(file.getAbsolutePath());
            ok = ok && !isExclusions(file.getAbsolutePath());
            ok = ok && matchExtensions(file.getName());
 
            return ok;
        }
    }, TrueFileFilter.INSTANCE);
%>
<!DOCTYPE html PUBLIC "-/W3C/DTD XHTML 1.0 Transitional/EN" "http:/www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http:/www.w3.org/1999/xhtml" lang="ko" xml:lang="ko">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>files</title>
</head>
<body>
<h3>File Count: <%=files.size()%></h3>
<ul>
<%   for(File file : files){
        String path = getPath(ctxtName, idx, file);
%>
    <li><a href='<%=path%>'><%=path%></a></li>
<%   } %>
</ul>
</body>
</html>
