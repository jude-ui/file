//임시스크립트
$(function(){
    // 스크롤시
    $(window).scroll(function (){
      var _h = $(document).scrollTop();
      var boxBasic = $('.head_service').height();

      // 높이값 지정
      if(_h > boxBasic){
        $('.container-doc').addClass('scroll');
      } else {
        $('.container-doc').removeClass('scroll');
      }

    });
});

